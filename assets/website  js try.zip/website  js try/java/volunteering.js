function resetForm() {
    document.getElementById('volunteerForm').reset();
    document.getElementById('fullNameError').textContent = '';
    document.getElementById('emailError').textContent = '';
    document.getElementById('aboutError').textContent = '';
    document.getElementById('contactError').textContent = '';
    document.getElementById('dobError').textContent = '';
    closePopup(); // Close the popup if it's open
}

function validateForm() {
    let isValid = true;

    // Validate Full Name
    const fullName = document.getElementById('fullName').value;
    if (fullName.trim() === '') {
        document.getElementById('fullNameError').textContent = 'Please fill the field.';
        isValid = false;
    } else {
        document.getElementById('fullNameError').textContent = '';
    }

    // Validate Email
    const email = document.getElementById('email').value;
    if (email.trim() === '' || !email.includes('@')) {
        document.getElementById('emailError').textContent = 'Please enter a valid email address.';
        isValid = false;
    } else {
        document.getElementById('emailError').textContent = '';
    }

    // Validate About
    const about = document.getElementById('about').value;
    if (about.trim() === '') {
        document.getElementById('aboutError').textContent = 'Please fill the field.';
        isValid = false;
    } else {
        document.getElementById('aboutError').textContent = '';
    }

    // Validate Contact
    const contact = document.getElementById('contact').value;
    if (contact.trim() === '' || isNaN(contact)) {
        document.getElementById('contactError').textContent = 'Please enter a valid phone number.';
        isValid = false;
    } else {
        document.getElementById('contactError').textContent = '';
    }

    // Validate Date of Birth
    const dob = document.getElementById('dob').value;
    if (dob.trim() === '') {
        document.getElementById('dobError').textContent = 'Please select a date of birth.';
        isValid = false;
    } else {
        document.getElementById('dobError').textContent = '';
    }

    if (isValid) {
        showPopup();
    }
}

function showPopup() {
    document.getElementById('popup').style.display = 'block';
}

function closePopup() {
    document.getElementById('popup').style.display = 'none';
    resetForm(); // Reset the form when the popup is closed
}