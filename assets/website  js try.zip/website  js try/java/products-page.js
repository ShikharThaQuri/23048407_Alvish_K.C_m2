function showPaymentPopup() {
    var iframe = document.getElementById('paymentIframe');
    iframe.src = 'paymentoption.html'; // Set the source to your payment page
    document.getElementById('popup').style.display = 'block';
}

function closePopup() {
    document.getElementById('popup').style.display = 'none';
}

document.querySelector('.btn-productpage').addEventListener('click', function(event) {
    event.preventDefault();
    showPaymentPopup();
});