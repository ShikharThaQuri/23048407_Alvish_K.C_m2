function resetForm() {
    document.getElementById('purchaseForm').reset();
    document.getElementById('nameError').textContent = '';
    document.getElementById('esewaNumberError').textContent = '';
    document.getElementById('emailError').textContent = '';
    document.getElementById('cityError').textContent = '';
    document.getElementById('addressError').textContent = '';
    document.getElementById('landmarkError').textContent = '';
}

function validateForm() {
    let isValid = true;

    // Validate Name
    const name = document.getElementById('name').value;
    if (name.trim() === '') {
        document.getElementById('nameError').textContent = 'Please fill the field.';
        isValid = false;
    } else {
        document.getElementById('nameError').textContent = '';
    }

    // Validate Esewa Number (must be numeric)
    const esewaNumber = document.getElementById('esewaNumber').value;
    if (esewaNumber.trim() === '' || isNaN(esewaNumber)) {
        document.getElementById('esewaNumberError').textContent = 'Please enter a valid Esewa number.';
        isValid = false;
    } else {
        document.getElementById('esewaNumberError').textContent = '';
    }

    // Validate Email (must end with .gmail.com)
    const email = document.getElementById('email').value;
    if (email.trim() === '' || !email.endsWith('@gmail.com')) {
        document.getElementById('emailError').textContent = 'Please enter a valid email address ending with @gmail.com.';
        isValid = false;
    } else {
        document.getElementById('emailError').textContent = '';
    }

    // Validate City
    const city = document.getElementById('city').value;
    if (city.trim() === '') {
        document.getElementById('cityError').textContent = 'Please fill the field.';
        isValid = false;
    } else {
        document.getElementById('cityError').textContent = '';
    }

    // Validate Address
    const address = document.getElementById('address').value;
    if (address.trim() === '') {
        document.getElementById('addressError').textContent = 'Please fill the field.';
        isValid = false;
    } else {
        document.getElementById('addressError').textContent = '';
    }

    // Validate Landmark
    const landmark = document.getElementById('landmark').value;
    if (landmark.trim() === '') {
        document.getElementById('landmarkError').textContent = 'Please fill the field.';
        isValid = false;
    } else {
        document.getElementById('landmarkError').textContent = '';
    }

    if (isValid) {
        showPopup();
    }
}

function showPopup() {
    document.getElementById('popup').style.display = 'block';
}

function closePopup() {
    document.getElementById('popup').style.display = 'none';
    resetForm(); // Reset the form when the popup is closed
}