function resetForm() {
    document.getElementById('donationForm').reset();
    document.getElementById('nameError').textContent = '';
    document.getElementById('esewaNumberError').textContent = '';
    document.getElementById('emailError').textContent = '';
    document.getElementById('amountError').textContent = '';
}

function validateForm() {
    let isValid = true;

    // Validate Name
    const name = document.getElementById('name').value;
    if (name.trim() === '') {
        document.getElementById('nameError').textContent = 'Please fill the field.';
        isValid = false;
    } else {
        document.getElementById('nameError').textContent = '';
    }

    // Validate Esewa Number (must be numeric)
    const esewaNumber = document.getElementById('esewaNumber').value;
    if (esewaNumber.trim() === '' || isNaN(esewaNumber)) {
        document.getElementById('esewaNumberError').textContent = 'Please enter a valid Esewa number.';
        isValid = false;
    } else {
        document.getElementById('esewaNumberError').textContent = '';
    }

    // Validate Email (must end with .gmail.com)
    const email = document.getElementById('email').value;
    if (email.trim() === '' || !email.endsWith('@gmail.com')) {
        document.getElementById('emailError').textContent = 'Please enter a valid email address ending with @gmail.com.';
        isValid = false;
    } else {
        document.getElementById('emailError').textContent = '';
    }

    // Validate Amount (must be a positive number)
    const amount = document.getElementById('amount').value;
    if (amount.trim() === '' || isNaN(amount) || amount <= 0) {
        document.getElementById('amountError').textContent = 'Please enter a valid amount.';
        isValid = false;
    } else {
        document.getElementById('amountError').textContent = '';
    }

    if (isValid) {
        showPopup();
    }
}

function showPopup() {
    document.getElementById('popup').style.display = 'block';
}

function closePopup() {
    document.getElementById('popup').style.display = 'none';
    resetForm(); // Reset the form when the popup is closed
}