function validateContactForm() {
    let isValid = true;

    // Validate First Name
    const firstName = document.getElementById('firstName').value;
    if (firstName.trim() === '') {
        document.getElementById('firstNameError').textContent = 'Please fill the field.';
        isValid = false;
    } else {
        document.getElementById('firstNameError').textContent = '';
    }

    // Validate Last Name
    const lastName = document.getElementById('lastName').value;
    if (lastName.trim() === '') {
        document.getElementById('lastNameError').textContent = 'Please fill the field.';
        isValid = false;
    } else {
        document.getElementById('lastNameError').textContent = '';
    }

    // Validate Email
    const email = document.getElementById('email').value;
    if (email.trim() === '' || email.indexOf('@') === -1 || email.indexOf('.') === -1) {
        document.getElementById('emailError').textContent = 'Please enter a valid email address.';
        isValid = false;
    } else {
        document.getElementById('emailError').textContent = '';
    }

    // Validate Phone Number
    const phoneNumber = document.getElementById('phoneNumber').value;
    if (phoneNumber.trim() === '' || isNaN(phoneNumber)) {
        document.getElementById('phoneNumberError').textContent = 'Please enter a valid phone number.';
        isValid = false;
    } else {
        document.getElementById('phoneNumberError').textContent = '';
    }

    // Validate Message
    const message = document.getElementById('message').value;
    if (message.trim() === '') {
        document.getElementById('messageError').textContent = 'Please fill the field.';
        isValid = false;
    } else {
        document.getElementById('messageError').textContent = '';
    }

    if (isValid) {
        showPopup();
    }
}

function showPopup() {
    document.getElementById('popup').style.display = 'block';
}

function closePopup() {
    document.getElementById('popup').style.display = 'none';
    document.getElementById('contactForm').reset();
}